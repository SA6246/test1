#pragma error FAILURE

raise Exception("FAILURE")