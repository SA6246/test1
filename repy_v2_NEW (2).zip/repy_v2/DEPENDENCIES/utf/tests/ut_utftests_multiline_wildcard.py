# Ensure the simplest case for wildcard passes

#pragma out
print "Test message one"
print "Test message two"
print "Test message three"