#pragma out PASS

print "PASS"