# This test should fail since error message one is not printed out.

#pragma out message one
#pragma out message two
print "Test message two"
