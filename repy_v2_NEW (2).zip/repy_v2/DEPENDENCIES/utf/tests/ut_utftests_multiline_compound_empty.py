# Ensure that wildcards don't need to contain data

#pragma out
#pragma out Test message one
#pragma out Test message two
#pragma out 
#pragma out Test message three
#pragma out 
print "Test message one"
print "Test message two"
print "Test message three"