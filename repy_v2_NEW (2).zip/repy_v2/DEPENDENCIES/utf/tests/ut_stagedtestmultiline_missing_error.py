# This test should fail since error message one is not printed out.

#pragma error message one
#pragma error message two
print "Error message two"
