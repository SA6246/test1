#pragma repy

getruntime()