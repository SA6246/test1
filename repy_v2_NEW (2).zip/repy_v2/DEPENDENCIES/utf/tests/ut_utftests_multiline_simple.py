# Simplest case for multiline statement

#pragma out Test message one
#pragma out Test message two
#pragma out Test message three
print "Test message one"
print "Test message two"
print "Test message three"