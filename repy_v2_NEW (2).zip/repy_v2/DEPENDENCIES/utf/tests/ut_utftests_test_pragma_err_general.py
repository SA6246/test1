#pragma error

raise Exception("FAILURE")