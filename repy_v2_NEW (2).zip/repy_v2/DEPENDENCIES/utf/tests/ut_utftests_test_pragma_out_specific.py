#pragma out hooray

print "hooray"