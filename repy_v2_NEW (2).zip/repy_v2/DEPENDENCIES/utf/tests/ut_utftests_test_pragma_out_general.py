#pragma out

print "There should be some sort of output, but it will pass"