"""
Example library used to demonstrate import-override rules.
"""
foo = "examplelib.py's foo"
